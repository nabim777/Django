from django.contrib import admin
from home.models import Register
from django import forms
# Register your models here.
admin.site.register(Register)